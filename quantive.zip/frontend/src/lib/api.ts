import axios from "axios";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api/v1",
  timeout: 30_000,
});

// Attach access token
api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem("quantive-auth");
      if (raw) {
        const { state } = JSON.parse(raw);
        if (state?.accessToken) {
          config.headers.Authorization = `Bearer ${state.accessToken}`;
        }
      }
    } catch {}
  }
  return config;
});

// Auto-refresh on 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const raw = localStorage.getItem("quantive-auth");
        if (raw) {
          const { state } = JSON.parse(raw);
          if (state?.refreshToken) {
            const { data } = await axios.post(
              `${original.baseURL ?? ""}/auth/refresh`,
              { refresh_token: state.refreshToken }
            );
            // Update store
            const stored = JSON.parse(raw);
            stored.state.accessToken = data.access_token;
            localStorage.setItem("quantive-auth", JSON.stringify(stored));
            original.headers.Authorization = `Bearer ${data.access_token}`;
            return api(original);
          }
        }
      } catch {
        localStorage.removeItem("quantive-auth");
        window.location.href = "/auth/login";
      }
    }
    return Promise.reject(error);
  }
);

// ── API METHODS ───────────────────────────────────────────────────────────────

export const authApi = {
  login: (email: string, password: string) =>
    api.post("/auth/login", { email, password }),
  register: (email: string, password: string, full_name: string) =>
    api.post("/auth/register", { email, password, full_name }),
};

export const tradesApi = {
  list: (params?: { limit?: number; symbol?: string; session?: string }) =>
    api.get("/trades/", { params }),
  importMT5: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return api.post("/trades/import/mt5", form);
  },
  delete: (id: string) => api.delete(`/trades/${id}`),
};

export const analyticsApi = {
  get: () => api.get("/analytics/"),
};

export const aiApi = {
  list: () => api.get("/ai/"),
  generate: () => api.post("/ai/generate"),
};

export const calendarApi = {
  list: (params?: { impact?: string }) => api.get("/calendar/", { params }),
};

export const usersApi = {
  me: () => api.get("/users/me"),
};

export default api;
