import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { analyticsApi, tradesApi, aiApi, calendarApi, usersApi } from "@/lib/api";

export const KEYS = {
  analytics: ["analytics"] as const,
  trades: (params?: object) => ["trades", params] as const,
  insights: ["insights"] as const,
  calendar: (impact?: string) => ["calendar", impact] as const,
  me: ["me"] as const,
};

export function useAnalytics() {
  return useQuery({
    queryKey: KEYS.analytics,
    queryFn: () => analyticsApi.get().then((r) => r.data),
    staleTime: 60_000,
  });
}

export function useTrades(params?: { symbol?: string; session?: string }) {
  return useQuery({
    queryKey: KEYS.trades(params),
    queryFn: () => tradesApi.list(params).then((r) => r.data),
  });
}

export function useInsights() {
  return useQuery({
    queryKey: KEYS.insights,
    queryFn: () => aiApi.list().then((r) => r.data),
  });
}

export function useCalendar(impact?: string) {
  return useQuery({
    queryKey: KEYS.calendar(impact),
    queryFn: () => calendarApi.list({ impact }).then((r) => r.data),
  });
}

export function useMe() {
  return useQuery({
    queryKey: KEYS.me,
    queryFn: () => usersApi.me().then((r) => r.data),
    staleTime: 300_000,
  });
}

export function useImportTrades() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (file: File) => tradesApi.importMT5(file).then((r) => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: KEYS.analytics });
      qc.invalidateQueries({ queryKey: ["trades"] });
      qc.invalidateQueries({ queryKey: KEYS.insights });
    },
  });
}

export function useGenerateInsights() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => aiApi.generate().then((r) => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: KEYS.insights });
    },
  });
}
