import { create } from "zustand";
import { persist } from "zustand/middleware";

interface User {
  id: string;
  email: string;
  full_name: string;
  role: string;
  timezone: string;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  setAuth: (user: User, access: string, refresh: string) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      setAuth: (user, accessToken, refreshToken) =>
        set({ user, accessToken, refreshToken }),
      clearAuth: () => set({ user: null, accessToken: null, refreshToken: null }),
    }),
    { name: "quantive-auth" }
  )
);

// ── UI STATE ──────────────────────────────────────────────────────────────────
interface UIState {
  sidebarCollapsed: boolean;
  activeTimeframe: "week" | "month" | "quarter" | "all";
  toggleSidebar: () => void;
  setTimeframe: (tf: UIState["activeTimeframe"]) => void;
}

export const useUIStore = create<UIState>((set) => ({
  sidebarCollapsed: false,
  activeTimeframe: "week",
  toggleSidebar: () =>
    set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setTimeframe: (tf) => set({ activeTimeframe: tf }),
}));
