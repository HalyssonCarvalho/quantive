"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, LineChart, BookOpen, Coins, Shield,
  CalendarDays, MessageSquareCode, Settings, Bell,
} from "lucide-react";

const NAV_ITEMS = [
  { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/analytics", icon: LineChart, label: "Analytics" },
  { href: "/journal", icon: BookOpen, label: "Journal" },
  { href: "/commodities", icon: Coins, label: "Commodities" },
  { href: "/risk", icon: Shield, label: "Risk" },
  { href: "/calendar", icon: CalendarDays, label: "Calendar" },
  { href: "/ai", icon: MessageSquareCode, label: "AI Copilot" },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <nav className="w-14 bg-[#111318] border-r border-white/[0.07] flex flex-col items-center py-4 gap-1 flex-shrink-0">
        {/* Logo */}
        <div className="w-8 h-8 bg-[#00d4aa] rounded-lg flex items-center justify-center mb-4">
          <span className="font-mono text-sm font-bold text-[#0a0c10]">Q</span>
        </div>

        {NAV_ITEMS.map(({ href, icon: Icon, label }) => {
          const active = pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              title={label}
              className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all
                ${active
                  ? "bg-[rgba(0,212,170,0.12)] text-[#00d4aa]"
                  : "text-gray-500 hover:bg-[#181c24] hover:text-gray-200"
                }`}
            >
              <Icon size={18} />
            </Link>
          );
        })}

        <div className="flex-1" />

        <Link
          href="/settings"
          title="Settings"
          className="w-10 h-10 rounded-lg flex items-center justify-center text-gray-500 hover:bg-[#181c24] hover:text-gray-200 transition-all"
        >
          <Settings size={18} />
        </Link>
      </nav>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="h-13 border-b border-white/[0.07] flex items-center px-5 gap-4 bg-[#111318] flex-shrink-0">
          <span className="font-mono text-[11px] text-gray-500 tracking-widest uppercase">
            <strong className="text-[#e8eaf0]">QUANTIVE</strong> — Dashboard
          </span>
          <div className="flex-1" />
          <MarketPill label="NY Session" active />
          <MarketPill label="XAU/USD" value="2 389.40" up />
          <MarketPill label="DXY" value="104.21" up={false} />
          <button className="relative w-8 h-8 rounded-lg bg-[#181c24] border border-white/[0.07] flex items-center justify-center text-gray-500 hover:text-gray-200">
            <Bell size={15} />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#00d4aa] border-2 border-[#111318]" />
          </button>
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#00d4aa] to-[#3b82f6] flex items-center justify-center text-[10px] font-semibold cursor-pointer">
            AJ
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}

function MarketPill({
  label,
  value,
  active,
  up,
}: {
  label: string;
  value?: string;
  active?: boolean;
  up?: boolean;
}) {
  return (
    <div className="flex items-center gap-1.5 bg-[#181c24] border border-white/[0.07] rounded-full px-2.5 py-1 text-[11px]">
      {active && (
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
      )}
      <span className="text-gray-400">{label}</span>
      {value && (
        <span
          className={`font-mono font-bold ${up ? "text-emerald-400" : "text-rose-400"}`}
        >
          {value}
        </span>
      )}
    </div>
  );
}
