"use client";

import { TrendingUp, Target, BarChart2, Zap, AlertTriangle } from "lucide-react";
import { useAnalytics } from "@/hooks/useQuantive";

interface MetricCardProps {
  label: string;
  value: string;
  sub: string;
  subUp?: boolean;
  accentColor: string;
  icon: React.ReactNode;
}

function MetricCard({ label, value, sub, subUp, accentColor, icon }: MetricCardProps) {
  return (
    <div className="relative bg-[#111318] border border-white/[0.07] rounded-xl p-4 overflow-hidden">
      <div
        className="absolute top-0 left-0 right-0 h-[2px]"
        style={{ background: accentColor }}
      />
      <div className="text-[10px] text-gray-500 uppercase tracking-[0.08em] mb-2 flex items-center gap-1.5">
        {icon}
        {label}
      </div>
      <div className="font-mono text-xl font-bold text-[#e8eaf0] leading-none">
        {value}
      </div>
      <div
        className={`text-[11px] mt-1.5 flex items-center gap-1 ${
          subUp === true
            ? "text-emerald-400"
            : subUp === false
            ? "text-rose-400"
            : "text-gray-500"
        }`}
      >
        {sub}
      </div>
    </div>
  );
}

export function MetricsRow() {
  const { data, isLoading } = useAnalytics();

  if (isLoading) {
    return (
      <div className="grid grid-cols-5 gap-2.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-24 rounded-xl bg-[#111318] animate-pulse" />
        ))}
      </div>
    );
  }

  const winPct = data ? (data.win_rate * 100).toFixed(1) : "—";
  const netPnl = data
    ? `${data.net_pnl >= 0 ? "+" : ""}$${data.net_pnl.toLocaleString()}`
    : "—";
  const drawdown = data
    ? `-${(data.max_drawdown * 100).toFixed(1)}%`
    : "—";
  const avgRr = data ? `1 : ${data.avg_rr.toFixed(1)}` : "—";
  const expectancy = data ? `$${data.expectancy.toFixed(2)}` : "—";

  return (
    <div className="grid grid-cols-5 gap-2.5">
      <MetricCard
        label="Net P&L"
        value={netPnl}
        sub="↑ +12.4% vs last week"
        subUp={true}
        accentColor="#10b981"
        icon={<TrendingUp size={12} />}
      />
      <MetricCard
        label="Win Rate"
        value={`${winPct}%`}
        sub={`${data?.total_trades ?? 0} total trades`}
        accentColor="#3b82f6"
        icon={<Target size={12} />}
      />
      <MetricCard
        label="Avg R:R"
        value={avgRr}
        sub="↑ +0.3 vs avg"
        subUp={true}
        accentColor="#fbbf24"
        icon={<BarChart2 size={12} />}
      />
      <MetricCard
        label="Expectancy"
        value={expectancy}
        sub="per trade"
        accentColor="#00d4aa"
        icon={<Zap size={12} />}
      />
      <MetricCard
        label="Max Drawdown"
        value={drawdown}
        sub="⚠ Limit: 5%"
        subUp={false}
        accentColor="#f43f5e"
        icon={<AlertTriangle size={12} />}
      />
    </div>
  );
}
