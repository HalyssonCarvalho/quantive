"use client";

import { Suspense } from "react";
import { MetricsRow } from "@/components/dashboard/MetricsRow";
import { EquityCurve } from "@/components/charts/EquityCurve";
import { SessionChart } from "@/components/charts/SessionChart";
import { RecentTrades } from "@/components/dashboard/RecentTrades";
import { InsightsPanel } from "@/components/dashboard/InsightsPanel";
import { CommoditiesPanel } from "@/components/dashboard/CommoditiesPanel";
import { CalendarPanel } from "@/components/dashboard/CalendarPanel";
import { AppShell } from "@/components/layout/AppShell";

export default function DashboardPage() {
  return (
    <AppShell>
      <div className="p-5 space-y-5">
        {/* Section: Performance Overview */}
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono uppercase tracking-widest text-gray-500">
            Performance Overview
          </span>
          <TimeframeSelector />
        </div>

        <Suspense fallback={<MetricsSkeleton />}>
          <MetricsRow />
        </Suspense>

        {/* Charts */}
        <div className="grid grid-cols-2 gap-3">
          <EquityCurve />
          <SessionChart />
        </div>

        {/* Bottom panels */}
        <div className="grid grid-cols-3 gap-3">
          <RecentTrades />
          <InsightsPanel />
          <div className="flex flex-col gap-3">
            <CommoditiesPanel />
            <CalendarPanel />
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function TimeframeSelector() {
  const options = ["Week", "Month", "Q1", "All"] as const;
  return (
    <div className="flex gap-2">
      {options.map((o) => (
        <button
          key={o}
          className="px-3 py-1 rounded-full text-[11px] border border-white/10 text-gray-400
                     hover:border-white/20 hover:text-gray-200 transition-all
                     first:bg-[rgba(0,212,170,0.1)] first:border-[#00d4aa] first:text-[#00d4aa]"
        >
          {o}
        </button>
      ))}
    </div>
  );
}

function MetricsSkeleton() {
  return (
    <div className="grid grid-cols-5 gap-2.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="h-24 rounded-xl bg-[#111318] animate-pulse" />
      ))}
    </div>
  );
}
