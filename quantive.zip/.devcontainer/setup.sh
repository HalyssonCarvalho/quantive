#!/bin/bash
set -e

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║        QUANTIVE — Dev Environment        ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. ENV FILE ───────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  echo "📋 Criando .env a partir do .env.example..."
  cp .env.example .env
  echo "⚠️  Lembre-se de preencher OPENAI_API_KEY no arquivo .env"
else
  echo "✅ .env já existe"
fi

# ── 2. BACKEND DEPENDENCIES ───────────────────────────────────────────────────
echo ""
echo "🐍 Instalando dependências Python..."
cd backend
pip install --upgrade pip -q
pip install -r requirements.txt -q
cd ..
echo "✅ Backend pronto"

# ── 3. FRONTEND DEPENDENCIES ──────────────────────────────────────────────────
echo ""
echo "📦 Instalando dependências Node.js..."
cd frontend
npm install --silent
cd ..
echo "✅ Frontend pronto"

# ── 4. WAIT FOR POSTGRES ──────────────────────────────────────────────────────
echo ""
echo "⏳ Aguardando PostgreSQL..."
for i in {1..30}; do
  if pg_isready -h localhost -p 5432 -U quantive -q 2>/dev/null; then
    echo "✅ PostgreSQL disponível"
    break
  fi
  sleep 2
done

# ── 5. RUN MIGRATIONS ─────────────────────────────────────────────────────────
echo ""
echo "🗄️  Criando tabelas no banco de dados..."
cd backend
python -c "
import asyncio
import sys
sys.path.insert(0, '.')
from app.core.database import init_db
asyncio.run(init_db())
print('✅ Tabelas criadas')
" 2>/dev/null || echo "⚠️  Banco ainda não disponível — rode manualmente depois"
cd ..

# ── DONE ──────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║           ✅ Setup concluído!            ║"
echo "╠══════════════════════════════════════════╣"
echo "║                                          ║"
echo "║  Frontend:  http://localhost:3000        ║"
echo "║  API:       http://localhost:8000        ║"
echo "║  API Docs:  http://localhost:8000/api/docs║"
echo "║                                          ║"
echo "║  Para iniciar tudo:                      ║"
echo "║    docker compose up -d                  ║"
echo "║                                          ║"
echo "║  Só o backend:                           ║"
echo "║    cd backend && uvicorn app.main:app    ║"
echo "║                                          ║"
echo "║  Só o frontend:                          ║"
echo "║    cd frontend && npm run dev            ║"
echo "║                                          ║"
echo "╚══════════════════════════════════════════╝"
echo ""
