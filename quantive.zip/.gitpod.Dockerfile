FROM gitpod/workspace-full:latest

RUN pyenv install 3.12 && pyenv global 3.12

RUN pip install --upgrade pip

USER gitpod
