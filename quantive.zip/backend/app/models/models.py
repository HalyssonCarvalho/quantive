import uuid
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float, ForeignKey,
    Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


def gen_uuid():
    return str(uuid.uuid4())


# ── ENUMS ─────────────────────────────────────────────────────────────────────

class UserRole(str, PyEnum):
    USER = "user"
    ANALYST = "analyst"
    ADMIN = "admin"
    INSTITUTIONAL = "institutional"


class TradeDirection(str, PyEnum):
    BUY = "buy"
    SELL = "sell"


class TradeSession(str, PyEnum):
    ASIAN = "asian"
    LONDON = "london"
    NEW_YORK = "new_york"
    OVERNIGHT = "overnight"


class InsightSeverity(str, PyEnum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class ImpactLevel(str, PyEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class EmotionalState(str, PyEnum):
    CALM = "calm"
    ANXIOUS = "anxious"
    CONFIDENT = "confident"
    FRUSTRATED = "frustrated"
    GREEDY = "greedy"
    FEARFUL = "fearful"


# ── MODELS ────────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=True)
    full_name = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), default=UserRole.USER, nullable=False)
    timezone = Column(String(64), default="UTC")
    preferred_assets = Column(String(512), default="")
    risk_profile = Column(String(64), default="moderate")
    trading_style = Column(String(64), default="swing")
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    trades = relationship("Trade", back_populates="user", cascade="all, delete-orphan")
    analytics = relationship("Analytics", back_populates="user", uselist=False)
    insights = relationship("AIInsight", back_populates="user", cascade="all, delete-orphan")
    journal_entries = relationship("JournalEntry", back_populates="user", cascade="all, delete-orphan")


class Trade(Base):
    __tablename__ = "trades"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    symbol = Column(String(32), nullable=False, index=True)
    direction = Column(Enum(TradeDirection), nullable=False)
    entry_price = Column(Float, nullable=False)
    exit_price = Column(Float, nullable=True)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    lot_size = Column(Float, nullable=False)
    pnl = Column(Float, nullable=True)
    rr = Column(Float, nullable=True)
    duration_minutes = Column(Integer, nullable=True)
    session = Column(Enum(TradeSession), nullable=True)
    is_closed = Column(Boolean, default=False)
    broker_trade_id = Column(String(128), nullable=True)
    opened_at = Column(DateTime(timezone=True), nullable=False)
    closed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="trades")
    journal_entry = relationship("JournalEntry", back_populates="trade", uselist=False)


class Analytics(Base):
    __tablename__ = "analytics"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    win_rate = Column(Float, default=0.0)
    avg_rr = Column(Float, default=0.0)
    expectancy = Column(Float, default=0.0)
    total_trades = Column(Integer, default=0)
    winning_trades = Column(Integer, default=0)
    losing_trades = Column(Integer, default=0)
    gross_profit = Column(Float, default=0.0)
    gross_loss = Column(Float, default=0.0)
    net_pnl = Column(Float, default=0.0)
    max_drawdown = Column(Float, default=0.0)
    consistency_score = Column(Float, default=0.0)
    best_session = Column(String(32), nullable=True)
    best_asset = Column(String(32), nullable=True)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user = relationship("User", back_populates="analytics")


class AIInsight(Base):
    __tablename__ = "ai_insights"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    insight = Column(Text, nullable=False)
    severity = Column(Enum(InsightSeverity), default=InsightSeverity.INFO)
    category = Column(String(64), nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="insights")


class EconomicEvent(Base):
    __tablename__ = "economic_events"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    title = Column(String(255), nullable=False)
    country = Column(String(8), nullable=False)
    currency = Column(String(8), nullable=True)
    impact = Column(Enum(ImpactLevel), nullable=False)
    event_time = Column(DateTime(timezone=True), nullable=False, index=True)
    forecast = Column(String(32), nullable=True)
    actual = Column(String(32), nullable=True)
    previous = Column(String(32), nullable=True)
    description = Column(Text, nullable=True)


class JournalEntry(Base):
    __tablename__ = "journal_entries"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    trade_id = Column(UUID(as_uuid=False), ForeignKey("trades.id", ondelete="SET NULL"), nullable=True)
    emotional_state = Column(Enum(EmotionalState), nullable=True)
    notes = Column(Text, nullable=True)
    setup_category = Column(String(64), nullable=True)
    screenshot_url = Column(String(512), nullable=True)
    rating = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    user = relationship("User", back_populates="journal_entries")
    trade = relationship("Trade", back_populates="journal_entry")
