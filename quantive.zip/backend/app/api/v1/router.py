from fastapi import APIRouter

from app.api.v1.routes import auth, trades, analytics, ai, users, calendar

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Auth"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(trades.router, prefix="/trades", tags=["Trades"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["Analytics"])
api_router.include_router(ai.router, prefix="/ai", tags=["AI"])
api_router.include_router(calendar.router, prefix="/calendar", tags=["Calendar"])
