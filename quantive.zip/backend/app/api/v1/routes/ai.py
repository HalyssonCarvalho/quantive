from typing import List
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.api.v1.deps import get_current_user
from app.models.models import User, AIInsight
from app.services.ai_service import generate_insights

router = APIRouter()


class InsightOut(BaseModel):
    id: str
    insight: str
    severity: str
    category: str
    is_read: bool
    created_at: str

    class Config:
        from_attributes = True


@router.post("/generate", response_model=List[InsightOut])
async def generate(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await generate_insights(db, current_user.id)


@router.get("/", response_model=List[InsightOut])
async def list_insights(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(AIInsight)
        .where(AIInsight.user_id == current_user.id)
        .order_by(desc(AIInsight.created_at))
        .limit(20)
    )
    return result.scalars().all()
