from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.api.v1.deps import get_current_user
from app.models.models import User
from app.services.analytics_service import compute_analytics

router = APIRouter()


@router.get("/")
async def get_analytics(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    analytics = await compute_analytics(db, current_user.id)
    return {
        "win_rate": analytics.win_rate,
        "avg_rr": analytics.avg_rr,
        "expectancy": analytics.expectancy,
        "total_trades": analytics.total_trades,
        "winning_trades": analytics.winning_trades,
        "losing_trades": analytics.losing_trades,
        "gross_profit": analytics.gross_profit,
        "gross_loss": analytics.gross_loss,
        "net_pnl": analytics.net_pnl,
        "max_drawdown": analytics.max_drawdown,
        "consistency_score": analytics.consistency_score,
        "best_session": analytics.best_session,
        "best_asset": analytics.best_asset,
    }
