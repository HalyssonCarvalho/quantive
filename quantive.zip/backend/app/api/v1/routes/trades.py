from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from pydantic import BaseModel
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.api.v1.deps import get_current_user
from app.models.models import Trade, User
from app.services.import_service import import_mt5_csv
from app.services.analytics_service import compute_analytics

router = APIRouter()


class TradeOut(BaseModel):
    id: str
    symbol: str
    direction: str
    entry_price: float
    exit_price: Optional[float]
    lot_size: float
    pnl: Optional[float]
    rr: Optional[float]
    session: Optional[str]
    is_closed: bool
    opened_at: str
    closed_at: Optional[str]

    class Config:
        from_attributes = True


class ImportResult(BaseModel):
    imported: int
    errors: List[str]


@router.get("/", response_model=List[TradeOut])
async def list_trades(
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    symbol: Optional[str] = None,
    session: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    q = select(Trade).where(Trade.user_id == current_user.id)
    if symbol:
        q = q.where(Trade.symbol == symbol.upper())
    if session:
        q = q.where(Trade.session == session)
    q = q.order_by(desc(Trade.opened_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return result.scalars().all()


@router.post("/import/mt5", response_model=ImportResult)
async def import_mt5(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files accepted")

    content = await file.read()
    imported, errors = await import_mt5_csv(db, current_user.id, content)

    # Recompute analytics after import
    if imported > 0:
        await compute_analytics(db, current_user.id)

    return ImportResult(imported=imported, errors=errors)


@router.delete("/{trade_id}", status_code=204)
async def delete_trade(
    trade_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Trade).where(Trade.id == trade_id, Trade.user_id == current_user.id)
    )
    trade = result.scalar_one_or_none()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")
    await db.delete(trade)
