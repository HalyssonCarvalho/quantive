from typing import List, Optional
from fastapi import APIRouter, Query
from pydantic import BaseModel
from datetime import date

router = APIRouter()


class EconomicEventOut(BaseModel):
    id: str
    title: str
    country: str
    impact: str
    event_time: str
    forecast: Optional[str]
    actual: Optional[str]
    previous: Optional[str]


@router.get("/", response_model=List[EconomicEventOut])
async def list_events(
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    impact: Optional[str] = Query(None, regex="^(low|medium|high)$"),
):
    # TODO: Integrate with Forex Factory / Investing.com API
    # Returning mock data for MVP
    return [
        {
            "id": "1",
            "title": "US CPI (YoY)",
            "country": "US",
            "impact": "high",
            "event_time": "2026-05-11T14:30:00Z",
            "forecast": "3.4%",
            "actual": None,
            "previous": "3.5%",
        },
        {
            "id": "2",
            "title": "FOMC Meeting Minutes",
            "country": "US",
            "impact": "high",
            "event_time": "2026-05-11T18:00:00Z",
            "forecast": None,
            "actual": None,
            "previous": None,
        },
    ]
