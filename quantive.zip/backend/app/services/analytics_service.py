from typing import List, Optional
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Trade, Analytics, TradeDirection


async def compute_analytics(db: AsyncSession, user_id: str) -> Analytics:
    """Recompute all analytics for a user from their trade history."""
    result = await db.execute(
        select(Trade).where(Trade.user_id == user_id, Trade.is_closed == True)
    )
    trades: List[Trade] = result.scalars().all()

    if not trades:
        return await _upsert_analytics(db, user_id, {})

    total = len(trades)
    winners = [t for t in trades if t.pnl and t.pnl > 0]
    losers = [t for t in trades if t.pnl and t.pnl < 0]

    win_rate = len(winners) / total if total > 0 else 0.0
    gross_profit = sum(t.pnl for t in winners)
    gross_loss = abs(sum(t.pnl for t in losers))
    net_pnl = gross_profit - gross_loss

    rr_values = [t.rr for t in trades if t.rr]
    avg_rr = sum(rr_values) / len(rr_values) if rr_values else 0.0

    # Expectancy = (Win Rate × Avg Win) - (Loss Rate × Avg Loss)
    avg_win = gross_profit / len(winners) if winners else 0.0
    avg_loss = gross_loss / len(losers) if losers else 0.0
    loss_rate = 1 - win_rate
    expectancy = (win_rate * avg_win) - (loss_rate * avg_loss)

    # Max drawdown
    max_drawdown = _calculate_max_drawdown(trades)

    # Consistency score (0–100)
    consistency = _calculate_consistency(trades)

    # Best session
    session_pnl: dict = {}
    for t in trades:
        if t.session and t.pnl:
            session_pnl.setdefault(t.session, 0)
            session_pnl[t.session] += t.pnl
    best_session = max(session_pnl, key=session_pnl.get) if session_pnl else None

    # Best asset
    asset_pnl: dict = {}
    for t in trades:
        if t.pnl:
            asset_pnl.setdefault(t.symbol, 0)
            asset_pnl[t.symbol] += t.pnl
    best_asset = max(asset_pnl, key=asset_pnl.get) if asset_pnl else None

    return await _upsert_analytics(db, user_id, {
        "win_rate": round(win_rate, 4),
        "avg_rr": round(avg_rr, 4),
        "expectancy": round(expectancy, 2),
        "total_trades": total,
        "winning_trades": len(winners),
        "losing_trades": len(losers),
        "gross_profit": round(gross_profit, 2),
        "gross_loss": round(gross_loss, 2),
        "net_pnl": round(net_pnl, 2),
        "max_drawdown": round(max_drawdown, 4),
        "consistency_score": round(consistency, 2),
        "best_session": best_session,
        "best_asset": best_asset,
    })


def _calculate_max_drawdown(trades: List[Trade]) -> float:
    """Calculate maximum drawdown as a fraction of peak equity."""
    sorted_trades = sorted(trades, key=lambda t: t.closed_at or t.opened_at)
    equity = 0.0
    peak = 0.0
    max_dd = 0.0

    for t in sorted_trades:
        if t.pnl:
            equity += t.pnl
            if equity > peak:
                peak = equity
            dd = (peak - equity) / peak if peak > 0 else 0.0
            if dd > max_dd:
                max_dd = dd

    return max_dd


def _calculate_consistency(trades: List[Trade]) -> float:
    """Score based on RR consistency and position sizing discipline."""
    if len(trades) < 5:
        return 50.0

    rr_values = [t.rr for t in trades if t.rr]
    if not rr_values:
        return 50.0

    avg = sum(rr_values) / len(rr_values)
    variance = sum((x - avg) ** 2 for x in rr_values) / len(rr_values)
    std_dev = variance ** 0.5

    # Lower std_dev relative to mean → higher consistency
    cv = std_dev / avg if avg > 0 else 1.0
    score = max(0.0, min(100.0, 100.0 - (cv * 50)))
    return score


async def _upsert_analytics(db: AsyncSession, user_id: str, data: dict) -> Analytics:
    result = await db.execute(
        select(Analytics).where(Analytics.user_id == user_id)
    )
    analytics = result.scalar_one_or_none()

    if analytics is None:
        analytics = Analytics(user_id=user_id)
        db.add(analytics)

    for key, value in data.items():
        setattr(analytics, key, value)

    await db.flush()
    return analytics
