import csv
import io
from datetime import datetime
from typing import List, Tuple

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Trade, TradeDirection, TradeSession


# ── MT5 CSV COLUMNS ───────────────────────────────────────────────────────────
MT5_COLUMNS = {
    "symbol": ["symbol", "instrument"],
    "direction": ["type", "direction", "side"],
    "entry_price": ["price", "entry", "open price"],
    "exit_price": ["close price", "exit", "close"],
    "stop_loss": ["s/l", "stop loss", "sl"],
    "take_profit": ["t/p", "take profit", "tp"],
    "lot_size": ["volume", "lots", "size"],
    "pnl": ["profit", "pnl", "p&l", "net profit"],
    "opened_at": ["open time", "open_time", "entry time"],
    "closed_at": ["close time", "close_time", "exit time"],
}


def _normalize_header(header: str) -> str:
    return header.strip().lower().replace(" ", "_")


def _find_column(row_keys: List[str], aliases: List[str]) -> str | None:
    for key in row_keys:
        if key.strip().lower() in aliases:
            return key
    return None


def _parse_direction(value: str) -> TradeDirection:
    v = value.strip().lower()
    if v in ("buy", "long", "0"):
        return TradeDirection.BUY
    return TradeDirection.SELL


def _parse_datetime(value: str) -> datetime:
    formats = [
        "%Y.%m.%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%Y-%m-%dT%H:%M:%S",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(value.strip(), fmt)
        except ValueError:
            continue
    raise ValueError(f"Cannot parse datetime: {value}")


def _detect_session(dt: datetime) -> TradeSession:
    hour = dt.hour  # UTC
    if 0 <= hour < 7:
        return TradeSession.ASIAN
    elif 7 <= hour < 12:
        return TradeSession.LONDON
    elif 12 <= hour < 20:
        return TradeSession.NEW_YORK
    return TradeSession.OVERNIGHT


def _calculate_rr(entry: float, exit_p: float, sl: float, direction: TradeDirection) -> float | None:
    if not sl or sl == 0:
        return None
    if direction == TradeDirection.BUY:
        risk = abs(entry - sl)
        reward = abs(exit_p - entry)
    else:
        risk = abs(sl - entry)
        reward = abs(entry - exit_p)
    return round(reward / risk, 2) if risk > 0 else None


async def import_mt5_csv(
    db: AsyncSession,
    user_id: str,
    csv_content: bytes,
) -> Tuple[int, List[str]]:
    """Parse MT5 history CSV and import trades. Returns (count, errors)."""

    text = csv_content.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text))
    headers = [h.strip().lower() for h in (reader.fieldnames or [])]

    imported = 0
    errors = []

    for i, row in enumerate(reader, start=2):
        try:
            row_keys = list(row.keys())

            symbol_key = _find_column(row_keys, MT5_COLUMNS["symbol"])
            direction_key = _find_column(row_keys, MT5_COLUMNS["direction"])
            entry_key = _find_column(row_keys, MT5_COLUMNS["entry_price"])
            exit_key = _find_column(row_keys, MT5_COLUMNS["exit_price"])
            lot_key = _find_column(row_keys, MT5_COLUMNS["lot_size"])
            pnl_key = _find_column(row_keys, MT5_COLUMNS["pnl"])
            opened_key = _find_column(row_keys, MT5_COLUMNS["opened_at"])
            closed_key = _find_column(row_keys, MT5_COLUMNS["closed_at"])
            sl_key = _find_column(row_keys, MT5_COLUMNS["stop_loss"])
            tp_key = _find_column(row_keys, MT5_COLUMNS["take_profit"])

            if not all([symbol_key, entry_key, lot_key]):
                errors.append(f"Row {i}: missing required columns")
                continue

            entry_price = float(row[entry_key].replace(",", "."))
            exit_price = float(row[exit_key].replace(",", ".")) if exit_key and row.get(exit_key) else None
            lot_size = float(row[lot_key].replace(",", "."))
            pnl = float(row[pnl_key].replace(",", ".")) if pnl_key and row.get(pnl_key) else None
            stop_loss = float(row[sl_key].replace(",", ".")) if sl_key and row.get(sl_key) else None
            take_profit = float(row[tp_key].replace(",", ".")) if tp_key and row.get(tp_key) else None
            direction = _parse_direction(row[direction_key]) if direction_key else TradeDirection.BUY
            opened_at = _parse_datetime(row[opened_key]) if opened_key and row.get(opened_key) else datetime.utcnow()
            closed_at = _parse_datetime(row[closed_key]) if closed_key and row.get(closed_key) else None
            session = _detect_session(opened_at)

            duration_minutes = None
            if closed_at:
                duration_minutes = int((closed_at - opened_at).total_seconds() / 60)

            rr = _calculate_rr(entry_price, exit_price, stop_loss, direction) if exit_price else None

            trade = Trade(
                user_id=user_id,
                symbol=row[symbol_key].strip().upper(),
                direction=direction,
                entry_price=entry_price,
                exit_price=exit_price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                lot_size=lot_size,
                pnl=pnl,
                rr=rr,
                duration_minutes=duration_minutes,
                session=session,
                is_closed=closed_at is not None,
                opened_at=opened_at,
                closed_at=closed_at,
            )
            db.add(trade)
            imported += 1

        except Exception as e:
            errors.append(f"Row {i}: {str(e)}")

    await db.flush()
    return imported, errors
