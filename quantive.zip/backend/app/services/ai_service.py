import json
from typing import List, Optional

from openai import AsyncOpenAI
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.models import AIInsight, Analytics, Trade, InsightSeverity

client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)


async def generate_insights(db: AsyncSession, user_id: str) -> List[AIInsight]:
    """Generate AI-powered behavioral and performance insights."""

    # Gather context
    analytics_result = await db.execute(
        select(Analytics).where(Analytics.user_id == user_id)
    )
    analytics = analytics_result.scalar_one_or_none()

    trades_result = await db.execute(
        select(Trade)
        .where(Trade.user_id == user_id, Trade.is_closed == True)
        .order_by(desc(Trade.closed_at))
        .limit(50)
    )
    recent_trades = trades_result.scalars().all()

    if not analytics or not recent_trades:
        return []

    summary = _build_summary(analytics, recent_trades)
    raw_insights = await _call_openai(summary)

    # Persist
    insights = []
    for item in raw_insights:
        insight = AIInsight(
            user_id=user_id,
            insight=item["insight"],
            severity=item.get("severity", InsightSeverity.INFO),
            category=item.get("category", "general"),
        )
        db.add(insight)
        insights.append(insight)

    await db.flush()
    return insights


def _build_summary(analytics: Analytics, trades: List[Trade]) -> dict:
    session_breakdown: dict = {}
    symbol_breakdown: dict = {}

    for t in trades:
        if t.session:
            session_breakdown.setdefault(t.session, {"pnl": 0, "count": 0})
            session_breakdown[t.session]["count"] += 1
            if t.pnl:
                session_breakdown[t.session]["pnl"] += t.pnl

        symbol_breakdown.setdefault(t.symbol, {"pnl": 0, "count": 0})
        symbol_breakdown[t.symbol]["count"] += 1
        if t.pnl:
            symbol_breakdown[t.symbol]["pnl"] += t.pnl

    consecutive_losses = _count_consecutive_losses(trades)

    return {
        "metrics": {
            "win_rate": analytics.win_rate,
            "avg_rr": analytics.avg_rr,
            "expectancy": analytics.expectancy,
            "max_drawdown": analytics.max_drawdown,
            "consistency_score": analytics.consistency_score,
            "net_pnl": analytics.net_pnl,
            "total_trades": analytics.total_trades,
        },
        "session_breakdown": session_breakdown,
        "symbol_breakdown": symbol_breakdown,
        "consecutive_losses": consecutive_losses,
        "best_session": analytics.best_session,
        "best_asset": analytics.best_asset,
    }


def _count_consecutive_losses(trades: List[Trade]) -> int:
    sorted_trades = sorted(
        trades,
        key=lambda t: t.closed_at or t.opened_at,
        reverse=True,
    )
    count = 0
    for t in sorted_trades:
        if t.pnl and t.pnl < 0:
            count += 1
        else:
            break
    return count


async def _call_openai(summary: dict) -> list:
    prompt = f"""You are a professional trading coach and behavioral analyst for a fintech platform called Quantive.

Analyze this trader's performance data and generate 3-5 actionable insights in JSON format.

TRADER DATA:
{json.dumps(summary, indent=2)}

Return a JSON array of insight objects. Each object must have:
- "insight": string (1-2 sentence human-readable insight, specific and actionable)
- "severity": one of "info", "warning", "critical"
- "category": one of "behavioral", "performance", "risk", "macro", "session", "pattern"

Focus on: overtrading, revenge trading, session-specific weaknesses, best opportunities, risk management.
Be specific — reference actual numbers from the data.
Return ONLY the JSON array, no other text."""

    try:
        response = await client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=1000,
        )
        content = response.choices[0].message.content.strip()
        return json.loads(content)
    except Exception as e:
        # Fallback rule-based insights if OpenAI fails
        return _rule_based_insights(summary)


def _rule_based_insights(summary: dict) -> list:
    insights = []
    metrics = summary.get("metrics", {})

    if summary.get("consecutive_losses", 0) >= 2:
        insights.append({
            "insight": f"You have {summary['consecutive_losses']} consecutive losses. Consider a mandatory 30-minute break to reset your mindset.",
            "severity": "warning",
            "category": "behavioral",
        })

    if metrics.get("win_rate", 0) < 0.45:
        insights.append({
            "insight": f"Your win rate of {metrics['win_rate']*100:.1f}% is below the 45% threshold. Review your entry criteria.",
            "severity": "warning",
            "category": "performance",
        })

    if metrics.get("max_drawdown", 0) > 0.04:
        insights.append({
            "insight": f"Max drawdown is at {metrics['max_drawdown']*100:.1f}%. Reduce position sizing until you recover.",
            "severity": "critical",
            "category": "risk",
        })

    best = summary.get("best_session")
    if best:
        session_data = summary.get("session_breakdown", {}).get(best, {})
        insights.append({
            "insight": f"Your best session is {best.replace('_', ' ').title()} with {session_data.get('count', 0)} trades. Focus more trading activity here.",
            "severity": "info",
            "category": "session",
        })

    return insights
