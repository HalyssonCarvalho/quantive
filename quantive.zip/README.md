# Quantive

**AI Trading & Commodities Intelligence Platform**

Institutional-grade SaaS fintech platform with AI-driven trading analytics, behavioral performance analysis, commodities intelligence, and macroeconomic monitoring.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 15, React, TypeScript, TailwindCSS, shadcn/ui |
| Charts | TradingView Lightweight Charts, Recharts |
| State | Zustand + TanStack Query |
| Backend | FastAPI (Python 3.12), SQLAlchemy async |
| Database | PostgreSQL 16 |
| Cache/Queue | Redis + Celery |
| AI | OpenAI GPT-4o |
| Storage | AWS S3 |
| Auth | JWT (+ Clerk optional) |
| Infra | Docker, Nginx, GitHub Actions → Railway |

---

## Quick Start

### 1. Clone and configure

```bash
git clone https://github.com/your-org/quantive
cd quantive
cp .env.example .env
# Edit .env — at minimum set SECRET_KEY and OPENAI_API_KEY
```

### 2. Start with Docker Compose

```bash
docker compose up -d
```

Services:
- Frontend: http://localhost:3000
- API: http://localhost:8000
- API Docs: http://localhost:8000/api/docs
- PostgreSQL: localhost:5432
- Redis: localhost:6379

### 3. Local development (without Docker)

**Backend:**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

---

## Project Structure

```
quantive/
├── backend/
│   └── app/
│       ├── api/v1/routes/      # Route handlers
│       ├── core/               # Config, DB, deps
│       ├── models/             # SQLAlchemy models
│       ├── services/           # Business logic
│       │   ├── auth_service.py
│       │   ├── analytics_service.py
│       │   ├── ai_service.py
│       │   └── import_service.py
│       ├── tasks/              # Celery tasks
│       └── websockets/         # Real-time feeds
├── frontend/
│   └── src/
│       ├── app/                # Next.js App Router
│       ├── components/         # UI components
│       ├── hooks/              # TanStack Query hooks
│       ├── store/              # Zustand stores
│       └── lib/                # API client
├── docker/
│   └── nginx.conf
├── .github/workflows/ci.yml
└── docker-compose.yml
```

---

## Key Modules

### Trade Import
Upload MT5 CSV exports via `POST /api/v1/trades/import/mt5`. The parser:
- Normalizes column names across broker formats
- Detects trading session (Asian / London / NY / Overnight)
- Calculates R:R from SL/TP
- Triggers analytics recomputation on success

### Analytics Engine
`GET /api/v1/analytics/` returns:
- Win rate, expectancy, avg R:R, max drawdown
- Consistency score (based on R:R coefficient of variation)
- Best performing session and asset

### AI Insights Engine
`POST /api/v1/ai/generate` analyzes the last 50 trades + analytics and uses GPT-4o to produce 3–5 behavioral insights. Falls back to rule-based engine if OpenAI is unavailable.

### Risk Management
Tracks daily loss limits, max drawdown thresholds, and overtrading patterns. Fires Celery alerts when limits are breached.

---

## Environment Variables

See `.env.example` for all available variables.

| Variable | Required | Description |
|---|---|---|
| `SECRET_KEY` | ✅ | JWT signing key |
| `DATABASE_URL` | ✅ | PostgreSQL async URL |
| `REDIS_URL` | ✅ | Redis connection string |
| `OPENAI_API_KEY` | ✅ | OpenAI API key |
| `AWS_ACCESS_KEY_ID` | For S3 | S3 uploads (journal screenshots) |
| `CLERK_SECRET_KEY` | Optional | Clerk Auth integration |

---

## Deployment

### Railway (MVP)

```bash
npm install -g @railway/cli
railway login
railway link
railway up
```

Set all environment variables in the Railway dashboard.

### AWS ECS (Production)

Use the GitHub Actions workflow (`ci.yml`) which:
1. Runs tests on every push
2. Builds Docker images on `main`
3. Pushes to GitHub Container Registry
4. Deploys via Railway CLI (swap for `aws ecs update-service` for ECS)

---

## Roadmap

| Phase | Features |
|---|---|
| MVP | Auth, trade import, dashboard, analytics, AI insights, economic calendar |
| Phase 2 | AI copilot chat, commodities heatmaps, advanced macro analytics |
| Phase 3 | Mobile apps, broker APIs, institutional dashboards, predictive AI |

---

## License

Proprietary — Quantive © 2026
